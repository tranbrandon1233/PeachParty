#include "StudentWorld.h"
#include "Actor.h"
#include "GameConstants.h"
#include "Board.h"
#include <string>

using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
	: GameWorld(assetPath), m_actors(), m_board()
{
}

int StudentWorld::init()
{

	//create board
	m_board = new Board();
	// create file name string
	std::string file = assetPath() + "board0" + std::to_string(getBoardNumber()) + ".txt";

	Board::LoadResult result = m_board->loadBoard(file);

	int i = 0;  //Track index of vector
	bool player1Used = false;  //Track if Peach is used for Player 1
	for (int gy = 0; gy < BOARD_HEIGHT; gy++) {  //For entire grid
		for (int gx = 0; gx < BOARD_WIDTH; gx++) {
			switch (m_board->getContentsOf(gx, gy)) {  //Switch to fill vector of actors
				case Board::blue_coin_square:   //Add blue coin squares
					addBlueCoin(SPRITE_WIDTH * gx, SPRITE_HEIGHT*gy);
					break;
				case Board::red_coin_square: //Add red coin squares
					addRedCoin(SPRITE_WIDTH * gx, SPRITE_HEIGHT * gy);
					break;
				default:
					break;
			}
			if (!player1Used && m_board->getContentsOf(gx, gy) == Board::player) {  //Add Peach if it has not been added yet
				addPeach(SPRITE_WIDTH*gx, SPRITE_HEIGHT*gy);
				addBlueCoin(SPRITE_WIDTH*gx, SPRITE_HEIGHT*gy);
				player1Used = true;

			}
			else if (player1Used && m_board->getContentsOf(gx, gy) == Board::player) {  //Add Yoshi after Peach has been added
				addYoshi(SPRITE_WIDTH*gx, SPRITE_HEIGHT*gy);
				addBlueCoin(SPRITE_WIDTH*gx, SPRITE_HEIGHT*gy);
			}
		}
	}
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.


	for (int i = 0; i < m_actors.size(); i++) {  //Call doSomething for all actors
		m_actors[i]->doSomething();
	}
    

	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	for (int i = 0; i < m_actors.size(); i++) {  //Delete all actors in vector
		delete m_actors[i];
	}
	m_actors.clear(); //Clear vector
	delete m_board;  //Delete board
}

bool StudentWorld::overlap(int x, int y, Actor* actor) const { //Check if there is an overlap at (x,y)
	switch(actor->getDirection()){ //Depending on the direction,
   		case 0:
			if (actor->getX() <= x && actor->getX() + VIEW_WIDTH - 1 >= x && actor->getY() == y) //Check if there is sprite overlap
				return true;
			break;
		case 90:
			if (actor->getY() <= y && actor->getY() + VIEW_HEIGHT - 1 >= y && actor->getX() == x) //Check if there is sprite overlap
				return true;
			break;
		case 180:
			if (actor->getX() >= x && actor->getX() - VIEW_WIDTH + 1 <= x && actor->getY() == y) //Check if there is sprite overlap
				return true;
			break;
		case 270:
			if (actor->getY() >= y && actor->getY() - VIEW_HEIGHT + 1 <= y && actor->getX() == x) //Check if there is sprite overlap
				return true;
			break;
		
	}
	return false; //Return fals if no overlap found
}

const bool StudentWorld::wallFound(int x, int y)  //Check if there is an overlap at (x,y)
{
        if (m_board->getContentsOf(x,y) != m_board->empty) {  //Check if there is overlap
			cerr << m_board->getContentsOf(x, y);
            return false;   //If so, return true
        }
  
    return true;   //If not found, return false
}
